﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameOverScript : MonoBehaviour
{
    public CoinUI coinScore;
    public GameObject gameOverPanel;
    public GameObject loseText;
    public GameObject winText;
    public Text winMessage;


    public PlayerController player;

    private void Start()
    {
       player.OnFinishLine += Win;
    }

    public void Lose()
    {
        gameOverPanel.SetActive(true);
        loseText.SetActive(true);
        Invoke("GameOver",5);
    }

    public void Win()
    {
        gameOverPanel.SetActive(true);
        winText.SetActive(true);
        winMessage.text = $"Your score is {coinScore.CoinCount}"; 
        Invoke("GameOver",5);
    }

    public void GameOver()
    {
        SceneManager.LoadScene("Menu");
    }
}
