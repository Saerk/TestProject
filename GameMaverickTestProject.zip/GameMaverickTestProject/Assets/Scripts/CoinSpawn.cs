﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinSpawn : MonoBehaviour
{
    public  GameObject coin;

    void Start()
    {
        for(int i = 0; i < 200; i++)
        {
            Instantiate(coin,
                        new Vector3(
                            Random.Range(0,200f),
                            10f,
                            Random.Range(0,200f)),
                        Quaternion.identity,
                        transform
                        );
        }
    }
}
