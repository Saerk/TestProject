﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations;

public class PlayerController : MonoBehaviour
{
    [SerializeField] 
    float _speed = 4;
    float _rotationPlayer;
    float _rotationSpeed = 90;

    public FixedJoystick Joystick;

    public event Action OnCoinPickUp;
    public event Action OnFinishLine;

    CharacterController controller;
    Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        controller = GetComponent<CharacterController>();   
        anim = GetComponent<Animator>();
    }

    void FixedUpdate()
    {
        Vector3 direction = transform.TransformDirection(Vector3.forward) * Joystick.Vertical;

        // walking backwards with half speed
        if(Joystick.Vertical < 0) direction *= (-1 / Joystick.Vertical * 0.5f);
        
        if(Joystick.Vertical != 0)
        {
            anim.SetBool("isWalking",true);
            
            if(Joystick.Vertical >= 0.5f)
            {
                anim.SetBool("isRunning",true);
            }
            else
            {
                anim.SetBool("isRunning",false);
            }
        }

        else
        {
            anim.SetBool("isRunning",false);
            anim.SetBool("isWalking",false);
        }
        
        _rotationPlayer += Joystick.Horizontal * Time.deltaTime * _rotationSpeed;
        transform.eulerAngles = new Vector3(0, _rotationPlayer, 0);

        controller.Move(direction * _speed * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
         if(other.tag == "Coin")
         {
            Destroy(other.gameObject);
            Debug.Log("+1");
            OnCoinPickUp?.Invoke();
         }
        if(other.tag == "Finish")
        {
            OnFinishLine?.Invoke();
        }
    }
}
