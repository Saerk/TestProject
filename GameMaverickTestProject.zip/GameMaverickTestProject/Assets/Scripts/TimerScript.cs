﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimerScript : MonoBehaviour
{
    float  _timer = 60;

    public Text TimerText;
    public GameOverScript gameOver;

    void Update()
    {
        _timer -= Time.deltaTime;
        TimerText.text = _timer.ToString("F0");
        if(_timer <= 0)
        {
            _timer = 0;
            gameOver.Lose();
        }
    }
}
