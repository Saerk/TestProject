﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CoinUI : MonoBehaviour
{
    public PlayerController player;
    public Text coinUi;

    private int _coinCount;

    public int CoinCount
    {
        get{return _coinCount;}
    }

    void RefreshCoinUi()
    {
        _coinCount++;
        coinUi.text = _coinCount.ToString();
    }

    void Start()
    {
        _coinCount = 0;
        player.OnCoinPickUp += RefreshCoinUi;
    }
}
