﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinHeight : MonoBehaviour
{   
    void OnEnable()
    {
        Ray ray = new Ray(transform.position, -transform.up);

        if(Physics.Raycast(ray, out RaycastHit hit))
        {
            transform.position = new Vector3(transform.position.x,hit.collider.transform.position.y + 0.5f, transform.position.z);
        }
        else
        {
            Debug.Log("ups");
        }
    }

}
